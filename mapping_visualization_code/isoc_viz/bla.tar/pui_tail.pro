;
; $Id: 
;
; pro pui_tail.pro
;
; This procedure generates a pui-tail distribution beyond the termination
; shock (in the downstream region).
;
; This uses the approximation that the pickup ion dist is
; 
;   [beta*nh/(8 pi u^4)] * [r1^2/(r*w^1.5)] * exp(-lambda/(r*w^1.5)) 
; 
; in the upstream region. Here, w = v/u where u is the solar wind speed.
; beta is the ionization rate at 1 AU. nH is the neutral density of
; interstellar H that makes it into the heliosphere. lambda is the
; distance (in AU) at which the ionization cutoff starts. 
; 
; We then apply the compression at the termination shock
;
;    v_up = v_dn/rs^(1/3)
;    w_up = w_dn/rs^(4/3)
;
; where v is speed and w is v/u
; rs is the compression ratio. 
;
; Finally, we add a tail with distribution power law gamma, and a
; suppression factor sup (factor the tail is down from the knee)

pro puid_tail,                  $
	beta=beta,              $ ; OPT_IN: ionization rate [1/s] at 1 AU
	lamb=lamb,              $ ; OPT_IN: Ionization cut-off in AU
	uswu=uswu,              $ ; OPT_IN: upwind solar wind spd [cm/s] 
        dens=dens,              $ ; OPT_IN: neutral int density [cm^-3]
        rats=rats,              $ ; OPT_IN: radial distance to TS     
        comp=comp,              $ ; OPT_IN: TS compression ratio
        supr=supr,              $ ; OPT_IN: factor the tail is down from the knee
        powl=powl,              $ ; OPT_IN: power-law for dist
        spda=spda,              $ ; OPT_IN: spda .. rad spdarray [cm/s] in fixed frame
        dist=dist                 ; OPT_OUT: distribution function [s^3/cm^6]

if not keyword_set(beta) then beta = 6.6e-7
if not keyword_set(lamb) then lamb = 3.0
if not keyword_set(uswu) then uswu = 300.0e5
if not keyword_set(dens) then dens = 0.1
if not keyword_set(rats) then rats = 100.0
if not keyword_set(comp) then comp = 2.5
if not keyword_set(powl) then powl = 5.0
if not keyword_set(supr) then supr = 1.0
if not keyword_set(spda) then begin
    n = 1000
    spda = 0.0 - 5.0*uswu*dindgen(n)/(n-1.0)
end
 
n = n_elements(spda)
dist = dblarr(n)
    
kB = 1.38d-16
mp  = 1.67d-24

for i=0, n-1 do begin
    vrd = abs(spda[i] - uswu/comp)
    vru = vrd/comp^(1.0/3.0)
    w = vru/uswu
    if (w lt 1.0) then $
      dist[i] = 0.0 $
    else begin
        dist_knee = (beta*dens*1.5e13/(8.0*!dpi*uswu^4)) * $
          ( 1.0 / (rats ) ) *exp(-lamb/(rats))
        dist[i] = dist_knee*supr*1.0/w^powl
    end
end

return
end

;
; eof
;
